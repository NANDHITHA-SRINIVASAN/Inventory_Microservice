package com.example.demo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.example.demo.Entity.Items;
import com.example.demo.Exceptions.InvalidItemIdException;
import com.example.demo.Exceptions.ItemNameAlreadyExistsException;
import com.example.demo.Service.ItemService;

@RestController
@RequestMapping("/api/items")
public class ItemController {

	@Autowired
	ItemService is;
	
	// http://localhost:8001/api/items/get-all-items
	@GetMapping("/get-all-items")
	 public List<Items> getAllItems() {
        return is.getAllItems();
    }
	
	// http://localhost:8001/api/items/get-item-by-id/{id}
	@GetMapping("/get-item-by-id/{id}")
    public ResponseEntity<?> getItemById(@PathVariable int id) {
        Items item = is.getItemById(id);
        if (item == null) {
            throw new InvalidItemIdException("Invalid  ID: " + id);
        }
        return ResponseEntity.ok(item);
    }
	

	
	 // Postman body-
//  {
//  "name": " ",
//  "category": " ",
//  "price": 
//  }       
	
//	http://localhost:8001/api/items/add-new-item
	@PostMapping("/add-new-item")
    public ResponseEntity<?> addNewItem(@RequestBody Items item) {
        try {
            Items newItem = is.addNewItem(item);
            return ResponseEntity.status(HttpStatus.CREATED).body(newItem);
        } catch (ItemNameAlreadyExistsException ex) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(ex.getMessage());
        }
    }
	

	
//	  {
//		  "name": "Air Purifier",
//		  "category": "Home Essentials",
//		  "price": 10000
//		  }
	
	
//	http://localhost:8001/api/items/update-item-by-id/{id}
	@PutMapping("/update-item-by-id/{id}")
    public ResponseEntity<?> updateItemById(@PathVariable int id, @RequestBody Items item) {
        Items updatedItem = is.updateItemById(id, item);
        return ResponseEntity.ok(updatedItem);
    }
	
	
//	http://localhost:8001/api/items/delete-item-by-id/{id}
	@DeleteMapping("/delete-item-by-id/{id}")
    public ResponseEntity<?> deleteItemById(@PathVariable int id) {
        try {
            List<Items> patients = is.deleteItemById(id);
            return ResponseEntity.ok(patients);
        } catch (InvalidItemIdException ex) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ex.getMessage());
        }
    }
	
	
	
	
	
	
	@ExceptionHandler(InvalidItemIdException.class)
    public ResponseEntity<String> handleInvalidItemIdException(InvalidItemIdException ex) {
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ex.getMessage());
    }
	
	
	@ExceptionHandler(ItemNameAlreadyExistsException.class)
    public ResponseEntity<String> handleItemNameAlreadyExistsException(
            ItemNameAlreadyExistsException ex) {
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(ex.getMessage());
    }
}
