package com.example.demo.Service;

import java.util.List;

import org.springframework.stereotype.Service;


import com.example.demo.Entity.Items;

@Service
public interface ItemService {

	Items getItemById(int id);

	List<Items> getAllItems();

	Items addNewItem(Items item);

	Items updateItemById(int id, Items item);

	List<Items> deleteItemById(int id);



	

	

	

}
