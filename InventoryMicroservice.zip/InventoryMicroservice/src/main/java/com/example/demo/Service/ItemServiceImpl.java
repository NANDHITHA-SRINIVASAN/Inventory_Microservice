package com.example.demo.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.example.demo.Entity.Items;
import com.example.demo.Exceptions.InvalidItemIdException;
import com.example.demo.Exceptions.ItemNameAlreadyExistsException;
import com.example.demo.Repository.ItemRepository;

@Service
public class ItemServiceImpl implements ItemService {
	
	@Autowired
	ItemRepository ir;

	@Override
	public List<Items> getAllItems() {
		// TODO Auto-generated method stub
		return ir.findAll();
	}
	
	
	@Override
	public Items getItemById(int id) {
		// TODO Auto-generated method stub
		Items i = ir.findById(id).orElse(null);
        return i;
	}


	@Override
	public Items addNewItem(Items item) {
		// TODO Auto-generated method stub
		// Check if a item with the same name already exists
        Items existingItem = ir.findByName(item.getName());
        if (existingItem != null) {
            throw new ItemNameAlreadyExistsException("Item with the same name already exists");
        }

        // Save the new item
        Items newItem = ir.save(item);
        return newItem;
	}

	@Override
	public Items updateItemById(int id, Items item) {
		// TODO Auto-generated method stub
		if (ir.existsById(id)) {
            item.setId(id);
            Items i = ir.save(item);
            return i;
        }
        return null;
	}

	@Override
	public List<Items> deleteItemById(int id) {
		// TODO Auto-generated method stub
		Items itemToDelete = ir.findById(id).orElse(null);
        if (itemToDelete == null) {
            throw new InvalidItemIdException("Invalid item ID: " + id);
        }
        ir.deleteById(id);
        List<Items> l = ir.findAll();
        return l;
	}

}
